<template>
    <div>
        <h2>{{msg}}</h2>
    </div>
</template>

<script>
    export default {
        name: "about-us",
        data() {
            return {
                'msg': '关于我们&联系我们&商务合作&新手指南'
            }
        }
    }
</script>

<style scoped>

</style>