<template>
    <div>
        <h2>{{msg}}</h2>
    </div>
</template>

<script>
    export default {
        name: "feedback",
        data(){
            return {
                msg:"意见反馈"
            }
        }
    }
</script>

<style scoped>

</style>