<template>
  <div>
    <h1>{{msg}}</h1>
  </div>
</template>

<script>
  export default {
    name: "index",
    data() {
      return {
        msg: '这是首页'
      }
    }
  }
</script>

<style scoped>

</style>
